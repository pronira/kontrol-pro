/* ═══════════════════════════════════════════════════════════
   gf-sources.js v4 — Джерела + Каталог готових джерел
   ─────────────────────────────────────────────────────────
   НОВІ ПОКРАЩЕННЯ v4:
     - gfShowScanLog: кнопка закрити через addEventListener (виправлено!)
     - gfShowScanLog: закрити по кліку на фон
     - gfShowScanLog: кнопка "🩺 Health check" для перевірки URL
     - gfShowScanLog: читабельні мітки кроків (STEP_LABELS)
     - gfShowScanLog: окреме відображення кожного типу кроку
     - gfShowScanLog: HTTP статус, розмір, content-type з rss_fetch
     - gfShowScanLog: відображення дат у фіді коли вікно занадто вузьке
     - gfShowScanLog: індикатор "relaxed" режиму фільтрації
     - gfShowScanLog: details[open] для кроків при помилці / HTTP fetch
     - Лог: покращений header запису з httpBadge

   ЗБЕРЕЖЕНО всі попередні покращення v3
   ═══════════════════════════════════════════════════════════ */

/* ── Каталог перевірених джерел ── */
var GF_CATALOG = [
  /* Сайти-агрегатори */
  {cat:'Сайти-агрегатори',id:'gurt_rss',name:'ГУРТ',url:'https://gurt.org.ua/news/grants/',type:'page',parser:'page_links',ico:'🌐',priority:'high',window_days:'30',topics:'Гранти, Можливості'},
  {cat:'Сайти-агрегатори',id:'prostir_feed',name:'Громадський Простір',url:'https://www.prostir.ua/category/grants/',type:'page',parser:'page_links',ico:'🌐',priority:'high',window_days:'30',topics:'Гранти, Конкурси'},
  {cat:'Сайти-агрегатори',id:'getgrant_page',name:'GetGrant',url:'https://getgrant.com.ua/grants/',type:'page',parser:'page_links',ico:'🌐'},
  {cat:'Сайти-агрегатори',id:'grant_market',name:'Grant.Market',url:'https://grant.market/grants',type:'page',parser:'page_links',ico:'🌐'},
  {cat:'Сайти-агрегатори',id:'granty_org_ua',name:'Granty.org.ua',url:'https://granty.org.ua/',type:'page',parser:'page_links',ico:'🌐'},
  {cat:'Сайти-агрегатори',id:'getgrant_ua',name:'GetGrant.ua',url:'https://getgrant.ua/',type:'page',parser:'page_links',ico:'🌐'},
  /* Telegram канали */
  {cat:'Telegram канали',id:'tg_grantovyphishky',name:'Грантові фішки',url:'https://t.me/s/grantovyphishky',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_gurtrc',name:'ГУРТ',url:'https://t.me/s/gaborets',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_prostirua',name:'Простір',url:'https://t.me/s/prostir_ua',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grant_market',name:'Grant.Market',url:'https://t.me/s/grant_market',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grants_here',name:'Гранти та можливості',url:'https://t.me/s/grants_here',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grantsua',name:'Гранти UA',url:'https://t.me/s/grantsua',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grantup',name:'GrantUP',url:'https://t.me/s/grantup',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grantovyphishky_eu',name:'Грантові фішки ЄС',url:'https://t.me/s/grantovyphishky_eu',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_ednannia',name:'ІСАР Єднання',url:'https://t.me/s/ednannia',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_ukf_ua',name:'УКФ',url:'https://t.me/s/ukf_ua',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_usaid_ukraine',name:'USAID Ukraine',url:'https://t.me/s/usaidukraine',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_undp_ukraine',name:'UNDP Ukraine',url:'https://t.me/s/undp_ukraine',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_eef_ukraine',name:'Фонд Сх. Європа',url:'https://t.me/s/eef_ukraine',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_houseofeurope',name:'House of Europe',url:'https://t.me/s/HouseofEuropeUA',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_diia_business',name:'Дія.Бізнес',url:'https://t.me/s/diia_business',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_giz_ukraine',name:'GIZ Ukraine',url:'https://t.me/s/giz_ukraine',type:'telegram',parser:'telegram',ico:'📱'},
  {cat:'Telegram канали',id:'tg_grantmanagement',name:'Grant Management',url:'https://t.me/s/grantmanagement',type:'telegram',parser:'telegram',ico:'📱'},
  /* Міжнародні донори */
  {cat:'Міжнародні донори',id:'undp_ukraine',name:'UNDP Ukraine',url:'https://www.undp.org/ukraine/news',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'house_of_europe',name:'House of Europe',url:'https://houseofeurope.org.ua/opportunities',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'eef_grants',name:'Фонд Сх. Європа',url:'https://eef.org.ua/konkursy-grantiv/',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'ednannia_grants',name:'ІСАР Єднання',url:'https://ednannia.ua/en/news',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'diia_business',name:'Дія.Бізнес',url:'https://business.diia.gov.ua/cases/grant',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'irex_ukraine',name:'IREX Ukraine',url:'https://www.irex.org/ukraine',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'opensociety_ua',name:'Open Society (МФВ)',url:'https://www.irf.ua/grants/',type:'page',parser:'page_links',ico:'🏛'},
  {cat:'Міжнародні донори',id:'irf_contests',name:'МФВ — конкурси та гранти',url:'https://www.irf.ua/grants/contests/',type:'page',parser:'page_links',ico:'🏛',priority:'high',window_days:'30',topics:'Громади, Відновлення',keywords:'грант,гранти,конкурс,відновлення,громада,можливість,підтримка'},
  {cat:'Міжнародні донори',id:'british_council_ua',name:'British Council Україна',url:'https://www.britishcouncil.org.ua/programmes',type:'page',parser:'page_links',ico:'🏛',priority:'medium',window_days:'30',topics:'Освіта, Культура',keywords:'грант,гранти,конкурс,можливість,підтримка,резиденція,call,applications'},
  /* Google News RSS */
  {cat:'Google News',id:'google_news_grants_ua',name:'Гранти Україна',url:'https://news.google.com/rss/search?q=гранти+Україна&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'},
  {cat:'Google News',id:'google_news_grants_hromady',name:'Гранти громади',url:'https://news.google.com/rss/search?q=гранти+для+громад&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'},
  {cat:'Google News',id:'google_news_konkursy',name:'Конкурси проєктів',url:'https://news.google.com/rss/search?q=конкурс+проєктів+Україна&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'},
  {cat:'Google News',id:'google_news_vidnovlennia',name:'Відновлення гранти',url:'https://news.google.com/rss/search?q=відновлення+грант+Україна&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'},
  /* Міжнародні RSS */
  {cat:'Міжнародні RSS',id:'fundsforngos_ukraine',name:'FundsforNGOs',url:'https://www2.fundsforngos.org/tag/ukraine/feed/',type:'rss',parser:'rss',ico:'🌍'},
  {cat:'Міжнародні RSS',id:'reliefweb_ukraine',name:'ReliefWeb UA',url:'https://reliefweb.int/updates/rss?country=254',type:'rss',parser:'rss',ico:'🌍'},
  {cat:'Міжнародні RSS',id:'reliefweb_funding',name:'ReliefWeb Funding',url:'https://reliefweb.int/jobs/rss?country=254&type=2',type:'rss',parser:'rss',ico:'🌍'},
  /* Додаткові */
  {cat:'Додаткові',id:'ucf_news',name:'УКФ (Укр. культурний фонд)',url:'https://ucf.in.ua/en/news',type:'page',parser:'page_links',ico:'🎭'},
  {cat:'Додаткові',id:'grant_av',name:'Грант АВ',url:'https://grant.av.ua/',type:'page',parser:'page_links',ico:'🌐'},
  {cat:'Додаткові',id:'eef_competitions',name:'Фонд Сх. Європа — конкурси',url:'https://eef.org.ua/konkursy-grantiv/',type:'page',parser:'page_links',ico:'🏛',priority:'high',window_days:'30',topics:'Громади, Відновлення',keywords:'грант,гранти,конкурс,відновлення,громада,community,grant,funding,application'},
  {cat:'Додаткові',id:'veteran_fund_contests',name:'Ветеранський фонд — конкурси',url:'https://veteranfund.com.ua/contests/',type:'page',parser:'page_links',ico:'🪖',priority:'high',window_days:'60',topics:'Ветерани, Підприємництво',keywords:'ветеран,ветерани,грант,конкурс,підприємництво,бізнес,grant,grants,funding'},
  {cat:'Google News',id:'google_news_business_grants',name:'Мікрогранти та бізнес',url:'https://news.google.com/rss/search?q=мікрогрант+бізнес+Україна&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'},
  {cat:'Google News',id:'google_news_veteran_grants',name:'Гранти для ветеранів',url:'https://news.google.com/rss/search?q=гранти+для+ветеранів+Україна&hl=uk&gl=UA&ceid=UA:uk',type:'rss',parser:'google_news_rss',ico:'📰'}
];

function gfFmtKyivDate(v) {
  if (!v) return '';
  var s = String(v).trim();
  if (!s) return '';
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(s)) return s.slice(0,16);
  var d = new Date(s);
  if (isNaN(d.getTime())) return s.slice(0,16).replace('T',' ');
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone:'Europe/Kyiv',
    year:'numeric', month:'2-digit', day:'2-digit',
    hour:'2-digit', minute:'2-digit', second:'2-digit',
    hour12:false
  }).format(d).replace(',', '').slice(0,16);
}

function gfDateMs(v) {
  if (!v) return 0;
  var s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(s)) {
    return new Date(s.replace(' ', 'T') + '+03:00').getTime();
  }
  var d = new Date(s);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}

function gfDefaultSourcePayload(c) {
  var baseKeywords = 'грант,гранти,грантова програма,конкурс,конкурси,можливість,можливості,фінансування,підтримка,подати заявку,відбір,стипендія,мікрогрант,subgrant,grant,grants,funding,call,open call,opportunity,application';
  var baseInclude  = 'грант,гранти,конкурс,можливість,фінансування,підтримка,грантова,подати заявку,стипендія,мікрогрант,grant,grants,funding,call,open call,opportunity,application,subgrant';
  var baseExclude  = 'вакансія,job,jobs,career,about,contact,login,privacy,cookie,sitemap,terms,register,signup,вебінар,розіграш';
  return {
    source_id: c.id,
    source_name: c.name,
    source_profile: c.id,
    source_url: c.url,
    source_type: c.type,
    parser_mode: c.parser,
    source_status: 'active',
    source_priority: c.priority || 'high',
    item_limit: String(c.item_limit || '20'),
    first_scan_mode: 'true',
    fetch_details: String(c.fetch_details || 'true'),
    scan_window_days: String(c.window_days || '30'),
    source_keywords: c.keywords || baseKeywords,
    link_include: c.include || baseInclude,
    link_exclude: c.exclude || baseExclude,
    geography_hint: c.geography_hint || 'Вся Україна, Громади',
    applicants_hint: c.applicants_hint || 'ОМС, Громадські організації, Заклади освіти',
    donor_hint: c.donor_hint || '',
    source_topics: c.topics || '',
    found_count: 0
  };
}

/* ═══════════════════════════════════════════════════════════
   ГОЛОВНИЙ ВИД ДЖЕРЕЛ
   ═══════════════════════════════════════════════════════════ */
function gfViewSources() {
  var src  = GF.data.sources  || [];
  var arch = GF.data.archive  || [];
  var active = src.filter(function(s) { return s.source_status === 'active'; });
  var paused = src.filter(function(s) { return s.source_status !== 'active'; });

  var view = GF.sourceView || 'active';
  // Рахуємо джерела з помилками
  var errSrc = src.filter(function(s) { return s.last_error || s.last_error_code; });
  var tabs = [
    ['active',   'Активні',          active.length],
    ['paused',   'Призупинені',       paused.length],
    ['errors',   '🚨 Помилки',        errSrc.length || ''],
    ['catalog',  '📚 Каталог',        GF_CATALOG.length],
    ['discover', '🔎 Нові джерела',   ''],
    ['archive',  'Архів',             arch.length]
  ];
  var th = '<div class="gf-tabs">';
  tabs.forEach(function(t) {
    th += '<button' + (view === t[0] ? ' class="active"' : '') +
          ' onclick="GF.sourceView=\'' + t[0] + '\';gfRender()">' +
          gfE(t[1]) + (t[2] !== '' ? ' (' + t[2] + ')' : '') + '</button>';
  });
  th += '</div>';

  if (view === 'catalog')  return gfViewCatalog(th, src);
  if (view === 'discover') return gfViewDiscover(th, src);
  if (view === 'errors')   return gfViewErrors(th, src);

  /* Quick add from URL */
  var addH = '<div style="margin-bottom:12px;padding:14px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--r)">'
    + '<div style="font-size:12px;font-weight:600;margin-bottom:8px">Швидке додавання</div>'
    + '<div style="display:grid;grid-template-columns:1fr 1fr auto;gap:8px;align-items:end">'
    + '<div class="gf-field" style="margin:0"><label>URL джерела</label><input id="gfNewSrcUrl" placeholder="https://t.me/s/channel"></div>'
    + '<div class="gf-field" style="margin:0"><label>Назва (необов\'язково)</label><input id="gfNewSrcName" placeholder="авто з URL"></div>'
    + '<button class="gf-btn" onclick="gfAddSrcFromUrl()" style="margin-bottom:1px">+ Додати</button>'
    + '</div></div>';

  /* Search */
  var sq = (GF.sourceSearch || '').toLowerCase();
  var searchH = '<div class="gf-search">'
    + '<input id="gfSrcSearch" placeholder="Пошук джерел…" value="' + gfE(sq) + '" onkeydown="if(event.keyCode===13)gfSrcDoSearch()">'
    + '<button class="gf-btn sm" onclick="gfSrcDoSearch()">🔍</button>'
    + (sq ? '<button class="gf-btn sm o" onclick="GF.sourceSearch=\'\';gfRender()">✕</button>' : '')
    + '</div>';

  var current = view === 'paused' ? paused : view === 'archive' ? arch : active;
  if (sq) {
    current = current.filter(function(s) {
      return [s.source_name,s.source_url,s.source_type,s.source_topics,s.notes].join(' ').toLowerCase().indexOf(sq) >= 0;
    });
  }

  var listH;
  if (!current.length) {
    listH = '<div class="gf-empty">' + (view === 'active'
      ? 'Немає активних джерел. Перейдіть на вкладку <b>📚 Каталог</b> щоб додати перевірені джерела.'
      : 'Немає джерел.') + '</div>';
  } else {
    listH = '<div class="gf-list">';
    current.forEach(function(s) {
      var ico = /telegram/i.test(s.source_type||'') ? '📱 '
              : /rss/i.test(s.source_type||'')      ? '📡 '
              : /google_news/i.test(s.parser_mode||'') ? '📰 ' : '🌐 ';
      var stBadge  = s.source_status === 'active'
        ? '<span class="gf-badge green">Активне</span>'
        : '<span class="gf-badge gray">Пауза</span>';
      var pCls = s.source_priority === 'critical' ? 'red'
               : s.source_priority === 'high'     ? 'green'
               : s.source_priority === 'medium'   ? 'yellow' : 'gray';
      var prioBadge = '<span class="gf-badge ' + pCls + '">' + gfE(s.source_priority||'—') + '</span>';

      listH += '<div class="gf-item"><div class="gf-item-head">'
        + '<h3>' + ico + gfE(s.source_name||'?') + '</h3>'
        + '<div style="display:flex;gap:4px">' + stBadge + prioBadge + '</div></div>'
        + '<div class="gf-item-meta">'
        + '<span>' + gfE(s.source_type||'') + '</span>'
        + '<span>' + gfE(s.parser_mode||'') + '</span>'
        + '<span>Всього: ' + (s.found_count||0) + '</span>'
        + (s.last_checked_at ? '<span>Перевірено: ' + gfE(gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '')) + '</span>' : '')
        + gfSrcLogBadge(s)
        + (s.last_error ? '<span style="color:var(--red)" title="' + gfE(s.last_error) + '">❌ Помилка</span>' : '')
        + (s.source_topics ? '<span>' + gfE(s.source_topics) + '</span>' : '')
        + '</div>'
        + '<div class="gf-muted" style="font-size:11px;word-break:break-all;margin-top:4px">' + gfE(s.source_url||'') + '</div>';

      if (view === 'archive') {
        listH += '<div class="gf-notice" style="margin-top:8px;font-size:11px">' + gfE(s.archive_reason||'') + '</div>';
      } else {
        listH += '<div class="gf-item-acts">'
          + (s.source_url ? '<button class="gf-btn sm o" title="Відкрити сайт" onclick="window.open(\'' + gfE(s.source_url) + '\',\'_blank\')">↗ Відкрити</button>' : '')
          + '<button class="gf-btn sm o" title="Редагувати" onclick="gfOpenSourceForm(\'' + gfE(s._id||s.source_id) + '\')">✏️</button>'
          + '<button class="gf-btn sm o" title="Лог сканування" onclick="gfShowScanLog(\'' + gfE(s._id||s.source_id) + '\',\'' + gfE(s.source_name||'') + '\')">📋 Лог</button>'
          + '<button class="gf-btn sm g" title="Примусове сканування" onclick="gfForceScan(\'' + gfE(s._id||s.source_id) + '\',\'' + gfE(s.source_name||'') + '\')">▶ Скан</button>'
          + '<button class="gf-btn sm o" title="' + (s.source_status==='active'?'Призупинити':'Відновити') + '" onclick="gfTogglePause(\'' + gfE(s._id||s.source_id) + '\')">'
          + (s.source_status === 'active' ? '⏸' : '▶') + '</button>'
          + '<button class="gf-btn sm r" title="Архівувати" onclick="gfArchiveSrc(\'' + gfE(s._id||s.source_id) + '\')">🗑</button>'
          + '</div>';
      }
      listH += '</div>';
    });
    listH += '</div>';
  }

  return '<div class="gf-panel"><div class="gf-panel-h"><h3>Джерела</h3>'
    + '<div style="display:flex;gap:6px;flex-wrap:wrap">'
    + '<span class="gf-badge blue">' + src.length + '</span>'
    + '<button class="gf-btn sm" onclick="gfOpenSourceForm()">+ Нове</button>'
    + '<button id="gfBulkScanBtn" class="gf-btn sm g" onclick="gfBulkScanAll()" style="font-size:10px" title="Послідовно просканувати всі активні джерела з прогресом">⏯ Масове сканування</button>'
    + '<button id="gfOpenReportBtn" class="gf-btn sm o" onclick="gfOpenFullReportTab()" style="font-size:10px" title="Повний звіт у новій вкладці">↗ Звіт</button>'
    + '<button id="gfDownloadReportBtn" class="gf-btn sm o" onclick="gfDownloadFullReport()" style="font-size:10px" title="Завантажити .txt">⬇</button>'
    + '<button class="gf-btn sm r" onclick="gfClearAllScanLogs()" style="font-size:10px" title="Очистити всі логи сканування. Зручно після деплою — бачитимеш тільки свіжі результати">🗑 Очистити звіт</button>'
    + '</div></div>'
    + th + (view !== 'archive' ? addH : '') + searchH + listH + '</div>';
}

/* ═══════════════════════════════════════════════════════════
   ЗВІТ ПО ПОМИЛКАХ — всі проблемні джерела в одному місці
   ═══════════════════════════════════════════════════════════ */
function gfViewErrors(tabsH, allSrc) {
  // Класифікація помилок
  var ERROR_META = {
    'TIMEOUT':       { icon:'⏱️', color:'#f59e0b', label:'Таймаут з\'єднання',    hint:'Сервер не відповідає за 30 сек. Перевірте чи сайт доступний.' },
    'ENOTFOUND':     { icon:'🔍', color:'#ef4444', label:'Домен не знайдено',      hint:'DNS не резолвить. Можливо сайт закритий або змінив адресу.' },
    'ECONNREFUSED':  { icon:'🚫', color:'#ef4444', label:'З\'єднання відхилено',   hint:'Сервер відмовляє у підключенні. Перевірте URL.' },
    'ECONNRESET':    { icon:'🔌', color:'#f59e0b', label:'З\'єднання перервано',   hint:'Сервер обірвав з\'єднання. Спробуйте пізніше.' },
    'ETIMEDOUT':     { icon:'⌛', color:'#f59e0b', label:'Таймаут мережі',         hint:'Сервер відповідає, але надто повільно.' },
    'HTTP_403':      { icon:'🔐', color:'#f59e0b', label:'Доступ заборонено 403',  hint:'Сервер блокує парсер. Можливо потрібна авторизація або інший парсер.' },
    'HTTP_404':      { icon:'❓', color:'#ef4444', label:'Сторінка не знайдена 404', hint:'URL більше не існує. Оновіть посилання.' },
    'HTTP_5XX':      { icon:'💥', color:'#f59e0b', label:'Помилка сервера 5xx',    hint:'Тимчасова проблема на стороні сервера.' },
    'SSL_ERROR':     { icon:'🔒', color:'#ef4444', label:'Помилка SSL',             hint:'Проблема з HTTPS сертифікатом сайту.' },
    'UNKNOWN':       { icon:'⚠️', color:'#94a3b8', label:'Невідома помилка',        hint:'Перегляньте деталі в логу сканування.' },
  };

  // Джерела з помилками
  var errSrc = allSrc.filter(function(s) { return s.last_error || s.last_error_code; });
  // Джерела що давно не сканувались успішно (>48 год)
  var stale = allSrc.filter(function(s) {
    if (!s.source_status || s.source_status !== 'active') return false;
    if (!s.last_checked_at) return true;
    var ms = Date.now() - gfDateMs(s.last_checked_at_kyiv || s.last_checked_at || '');
    return ms > 48 * 3600 * 1000;
  });
  // Унікалізуємо (dedup stale з errSrc)
  var staleOnly = stale.filter(function(s) {
    return !errSrc.find(function(e) { return (e._id||e.source_id) === (s._id||s.source_id); });
  });

  var h = '<div class="gf-panel"><div class="gf-panel-h"><h3>🚨 Звіт по помилках</h3>'
    + '<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">'
    + '<span class="gf-badge red">' + errSrc.length + ' помилок</span>'
    + (staleOnly.length ? '<span class="gf-badge yellow">' + staleOnly.length + ' застарілих</span>' : '')
    + '<button id="gfBulkScanBtnErr" class="gf-btn sm g" onclick="gfBulkScanAll()" style="font-size:10px">⏯ Масове сканування</button>'
    + '<button id="gfOpenReportBtn" class="gf-btn sm" onclick="gfOpenFullReportTab()" style="font-size:10px">↗ Відкрити у вкладці</button>'
    + '<button id="gfDownloadReportBtn" class="gf-btn sm o" onclick="gfDownloadFullReport()" style="font-size:10px">⬇ Завантажити (.txt)</button>'
    + '<button class="gf-btn sm o" onclick="gfCopyErrorReport()" style="font-size:10px">📋 Копіювати помилки</button>'
    + '<button class="gf-btn sm r" onclick="gfClearAllScanLogs()" style="font-size:10px" title="Видалити всі логи сканування. Корисно після деплою — потім будуть тільки свіжі результати">🗑 Очистити звіт</button>'
    + '</div></div>'
    + tabsH;

  if (!errSrc.length && !staleOnly.length) {
    return h + '<div class="gf-ok" style="margin:16px 0">✅ Всі активні джерела працюють без помилок.</div></div>';
  }

  // ── Статистика по типах помилок ──
  if (errSrc.length) {
    var byCode = {};
    errSrc.forEach(function(s) {
      var code = s.last_error_code || 'UNKNOWN';
      if (!byCode[code]) byCode[code] = 0;
      byCode[code]++;
    });
    h += '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px">';
    Object.keys(byCode).forEach(function(code) {
      var m = ERROR_META[code] || ERROR_META['UNKNOWN'];
      h += '<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:8px 14px;display:flex;align-items:center;gap:8px">'
        + '<span style="font-size:18px">' + m.icon + '</span>'
        + '<div><div style="font-size:12px;font-weight:700;color:' + m.color + '">' + gfE(m.label) + '</div>'
        + '<div style="font-size:10px;color:#64748b">' + byCode[code] + ' ' + (byCode[code] === 1 ? 'джерело' : 'джерел') + '</div></div>'
        + '</div>';
    });
    h += '</div>';

    // ── Список джерел з помилками ──
    h += '<div style="margin-bottom:8px;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.5px">Джерела з помилками (' + errSrc.length + ')</div>';
    h += '<div class="gf-list" style="margin-bottom:20px">';
    errSrc.forEach(function(s) {
      var code  = s.last_error_code || 'UNKNOWN';
      var meta  = ERROR_META[code] || ERROR_META['UNKNOWN'];
      var errMsg = s.last_error || s.last_scan_log && s.last_scan_log.error || '';
      var ll = s.last_scan_log || {};
      var lastCheck = gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '');
      var ico = /telegram/i.test(s.source_type||'') ? '📱' : /rss/i.test(s.source_type||'') ? '📡' : '🌐';
      var sid = s._id || s.source_id;
      var stage = '—';
      var steps = ll.diag_steps || [];
      if (steps.length) {
        var pe = steps.find(function(st){ return st.step === 'parse_error'; });
        if (pe) stage = 'parse_error';
        else if (ll.non_ua_dropped || ll.age_dropped) stage = 'selection_gates';
        else if (ll.after_filter === 0 && ll.raw_found > 0) stage = ll.fallback_mode ? 'filter_fallback' : 'filter';
        else if (ll.dupes) stage = 'dedup';
        else if (ll.created) stage = 'created';
      }

      h += '<div class="gf-item" style="padding:12px 16px;border-left:3px solid ' + meta.color + '">'
        + '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">'
        + '<div style="flex:1;min-width:0">'
        + '<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">'
        + '<span style="font-size:13px">' + ico + '</span>'
        + '<span style="font-size:13px;font-weight:700">' + gfE(s.source_name||'?') + '</span>'
        + '<span style="font-size:11px;background:rgba(255,255,255,.06);color:' + meta.color + ';padding:1px 7px;border-radius:4px">'
        + meta.icon + ' ' + gfE(meta.label) + '</span>'
        + '</div>'
        // Повідомлення помилки
        + (errMsg ? '<div style="font-size:11px;color:#fca5a5;margin-bottom:4px;word-break:break-all">' + gfE(errMsg.slice(0,200)) + '</div>' : '')
        // Підказка
        + '<div style="font-size:11px;color:#64748b;margin-bottom:4px">' + gfE(meta.hint) + '</div>'
        // URL + час перевірки
        + '<div style="font-size:10px;color:#475569;word-break:break-all">'
        + gfE(s.source_url||'')
        + (lastCheck ? ' · перевірено ' + lastCheck : '')
        + '</div>'
        + '<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:8px">'
        + gfLogCell('Етап', gfE(stage), '#93c5fd')
        + gfLogCell('Raw', ll.raw_found||0, '#e2e8f0')
        + gfLogCell('Після фільтру', ll.after_filter||0, '#fcd34d')
        + gfLogCell('HTTP', ll.http_status||'—', '#fca5a5')
        + '</div>'
        + '<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:6px">'
        + gfLogCell('>14 днів', ll.age_dropped||0, '#fb7185')
        + gfLogCell('Не UA', ll.non_ua_dropped||0, '#f97316')
        + gfLogCell('Fallback', ll.fallback_mode ? 'так' : 'ні', ll.fallback_mode ? '#10b981' : '#94a3b8')
        + '</div>'
        + '</div>'
        // Кнопки дій
        + '<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0">'
        + '<button class="gf-btn sm g" onclick="gfForceScan(\'' + gfE(sid) + '\',\'' + gfE(s.source_name||'') + '\')">▶ Скан</button>'
        + '<button class="gf-btn sm o" onclick="gfShowScanLog(\'' + gfE(sid) + '\',\'' + gfE(s.source_name||'') + '\')">📋 Лог</button>'
        + '<button class="gf-btn sm o" onclick="gfOpenSourceForm(\'' + gfE(sid) + '\')">✏️</button>'
        + '</div>'
        + '</div></div>';
    });
    h += '</div>';
  }

  // ── Застарілі джерела ──
  if (staleOnly.length) {
    h += '<div style="margin-bottom:8px;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.5px">Застарілі — не сканувались >48 год (' + staleOnly.length + ')</div>';
    h += '<div class="gf-list">';
    staleOnly.forEach(function(s) {
      var lastCheck = s.last_checked_at ? gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '') : 'ніколи';
      var sid = s._id || s.source_id;
      h += '<div class="gf-item" style="padding:10px 16px;border-left:3px solid #475569">'
        + '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px">'
        + '<div><div style="font-size:13px;font-weight:600">' + gfE(s.source_name||'?') + '</div>'
        + '<div style="font-size:10px;color:#64748b">Остання перевірка: ' + lastCheck + ' · ' + gfE(s.source_url||'') + '</div>'
        + '</div>'
        + '<button class="gf-btn sm g" onclick="gfForceScan(\'' + gfE(sid) + '\',\'' + gfE(s.source_name||'') + '\')">▶ Скан</button>'
        + '</div></div>';
    });
    h += '</div>';
  }

  return h + '</div>';
}

/* ═══════════════════════════════════════════════════════════
   ПОВНИЙ ЗВІТ — завантаження файлом або відкриття в редакторі
   ═══════════════════════════════════════════════════════════ */

/**
 * Будує текст повного звіту по всіх джерелах.
 * logs — масив документів з gf_scan_logs (останній запис кожного джерела)
 * sources — масив gf_sources
 */
function gfBuildFullReport(sources, logs) {
  var now = new Date().toLocaleString('uk-UA', { timeZone: 'Europe/Kyiv' });
  var lines = [];

  // ─── ЗАГОЛОВОК ───────────────────────────────────────────────
  lines.push('╔══════════════════════════════════════════════════════════════════╗');
  lines.push('║         ПОВНИЙ ЗВІТ ПАРСИНГУ — KONTROL PRO                      ║');
  lines.push('╚══════════════════════════════════════════════════════════════════╝');
  lines.push('Дата звіту : ' + now);
  lines.push('Джерел     : ' + sources.length);
  var active  = sources.filter(function(s){ return s.source_status === 'active'; }).length;
  var errCnt  = sources.filter(function(s){ return s.last_error || s.last_error_code; }).length;
  var okCnt   = sources.filter(function(s){ return !s.last_error && !s.last_error_code && s.last_scan_log && s.last_scan_log.status === 'ok_new'; }).length;
  lines.push('Активних   : ' + active);
  lines.push('З помилками: ' + errCnt);
  lines.push('Успішних   : ' + okCnt);
  lines.push('');

  // ─── ЗВЕДЕНА ТАБЛИЦЯ ─────────────────────────────────────────
  lines.push('══════════════════════════════════════════════════════════════════');
  lines.push('ЗВЕДЕНА ТАБЛИЦЯ ПО ДЖЕРЕЛАХ');
  lines.push('══════════════════════════════════════════════════════════════════');
  lines.push(padR('Назва', 26) + padR('Тип', 10) + padR('Парсер', 16) + padR('Статус', 12) + padR('Raw', 7) + padR('>14д', 6) + padR('НеUA', 6) + padR('Нових', 7) + padR('Дубл', 6) + 'Остання перевірка');
  lines.push('─'.repeat(125));

  sources.forEach(function(s) {
    var ll   = s.last_scan_log || {};
    var st   = s.last_error_code || ll.status || '—';
    var lc   = gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '');
    lines.push(
      padR((s.source_name||'?').slice(0,25), 26) +
      padR((s.source_type||'').slice(0,9), 10) +
      padR((s.parser_mode||ll.parser_mode||'').slice(0,15), 16) +
      padR(st.slice(0,11), 12) +
      padR(String(ll.raw_found||0), 7) +
      padR(String(ll.age_dropped||0), 6) +
      padR(String(ll.non_ua_dropped||0), 6) +
      padR(String(ll.created||0), 7) +
      padR(String(ll.dupes||0), 6) +
      (lc || '—')
    );
  });
  lines.push('');

  // ─── СТАТИСТИКА ПО МЕТОДАХ СКАНУВАННЯ ────────────────────────
  lines.push('══════════════════════════════════════════════════════════════════');
  lines.push('МЕТОДИ СКАНУВАННЯ (parser_mode)');
  lines.push('══════════════════════════════════════════════════════════════════');
  var parserStats = {};
  sources.forEach(function(s) {
    var p = s.parser_mode || (s.last_scan_log && s.last_scan_log.parser_mode) || 'невідомо';
    if (!parserStats[p]) parserStats[p] = { total:0, ok:0, err:0, found:0, created:0 };
    parserStats[p].total++;
    var ll = s.last_scan_log || {};
    if (s.last_error || s.last_error_code) parserStats[p].err++;
    else parserStats[p].ok++;
    parserStats[p].found   += ll.raw_found || 0;
    parserStats[p].created += ll.created || 0;
  });
  Object.keys(parserStats).sort().forEach(function(p) {
    var ps = parserStats[p];
    lines.push('  ' + padR(p, 20) + ' всього: ' + padR(String(ps.total),4) + ' | ok: ' + padR(String(ps.ok),4) + ' | помилок: ' + padR(String(ps.err),4) + ' | знайдено: ' + padR(String(ps.found),6) + ' | нових: ' + ps.created);
  });
  lines.push('');

  // ─── ДЕТАЛЬНИЙ БЛОК КОЖНОГО ДЖЕРЕЛА ──────────────────────────
  lines.push('══════════════════════════════════════════════════════════════════');
  lines.push('ДЕТАЛЬНИЙ ЛОГ ПО КОЖНОМУ ДЖЕРЕЛУ');
  lines.push('══════════════════════════════════════════════════════════════════');

  // Сортуємо: спочатку з помилками, потім решта
  var sorted = sources.slice().sort(function(a,b) {
    var ae = !!(a.last_error || a.last_error_code);
    var be = !!(b.last_error || b.last_error_code);
    if (ae && !be) return -1;
    if (!ae && be) return 1;
    return (a.source_name||'').localeCompare(b.source_name||'');
  });

  sorted.forEach(function(s) {
    var ll  = s.last_scan_log || {};
    var hasErr = !!(s.last_error || s.last_error_code);
    var sid = s._id || s.source_id || '—';
    lines.push('');
    lines.push((hasErr ? '❌ ' : '✅ ') + '══ ' + (s.source_name||'?') + ' ══');
    lines.push('  ID         : ' + sid);
    lines.push('  URL        : ' + (s.source_url||'—'));
    lines.push('  Тип        : ' + (s.source_type||'—'));
    lines.push('  Парсер     : ' + (s.parser_mode||ll.parser_mode||'—'));
    lines.push('  Статус     : ' + (s.source_status||'—'));
    lines.push('  Пріоритет  : ' + (s.source_priority||'—'));
    lines.push('  Вікно (дн) : ' + (s.scan_window_days||s.window_days||ll.window_days||7));
    lines.push('  Ліміт      : ' + (s.item_limit||10));
    lines.push('  Всього знайдено за весь час: ' + (s.found_count||0));
    lines.push('');
    lines.push('  ── Останнє сканування ──');
    lines.push('  Час        : ' + (gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '') || '—'));
    lines.push('  Статус     : ' + (ll.status||'—'));
    lines.push('  Знайдено   : ' + (ll.raw_found||0));
    lines.push('  Після фільтру: ' + (ll.after_filter||0));
    lines.push('  Відсіяно >14 днів: ' + (ll.age_dropped||0));
    lines.push('  Відсіяно не UA : ' + (ll.non_ua_dropped||0));
    lines.push('  Fallback фільтр: ' + (ll.fallback_mode ? 'так' : 'ні'));
    lines.push('  Нових      : ' + (ll.created||0));
    lines.push('  Дублів     : ' + (ll.dupes||0));
    lines.push('  Деталей    : ' + (ll.detailed||0));
    lines.push('  HTTP       : ' + (ll.http_status||'—'));
    lines.push('  Мульти     : ' + (ll.is_multi ? 'так' : 'ні'));

    if (hasErr) {
      lines.push('');
      lines.push('  ── ПОМИЛКА ──');
      lines.push('  Код        : ' + (s.last_error_code||'UNKNOWN'));
      lines.push('  Опис       : ' + (s.last_error_label||'—'));
      lines.push('  Повідомлення: ' + (s.last_error||ll.error||'—'));
    }

    // Діагностичні кроки з логу
    var steps = ll.diag_steps || [];
    if (steps.length) {
      lines.push('');
      lines.push('  ── Кроки діагностики ──');
      steps.forEach(function(step) {
        var data = Object.assign({}, step);
        delete data.step; delete data.ts;
        var dataStr = JSON.stringify(data);
        // Довгий stack — обрізаємо
        if (dataStr.length > 300) dataStr = dataStr.slice(0,300) + '…';
        lines.push('  [' + (step.ts||'') + '] ' + padR(step.step||'', 28) + ' ' + dataStr);
      });
    }

    // Попередження
    var warns = ll.diag_warnings || [];
    if (warns.length) {
      lines.push('');
      lines.push('  ── Попередження ──');
      // Групуємо
      var errW   = warns.filter(function(w){ return w.startsWith('Parse failed') || w.startsWith('Fatal'); });
      var dupW   = warns.filter(function(w){ return w.startsWith('dup_'); });
      var restW  = warns.filter(function(w){ return !w.startsWith('Parse failed') && !w.startsWith('Fatal') && !w.startsWith('dup_'); });
      if (errW.length)  { errW.forEach(function(w){ lines.push('  🚨 ' + w); }); }
      if (dupW.length)  { lines.push('  ♻️  Дублікатів пропущено: ' + dupW.length);
        dupW.slice(0,10).forEach(function(w){ lines.push('     ' + w); });
        if (dupW.length>10) lines.push('     … ще ' + (dupW.length-10));
      }
      if (restW.length) { restW.slice(0,10).forEach(function(w){ lines.push('  ⚠️  ' + w); }); }
    }

    // Логи з Firestore (якщо є в масиві logs)
    var srcLogs = logs.filter(function(l){ return l.source_id === sid; })
      .sort(function(a,b){ return (b.scanned_at||'') > (a.scanned_at||'') ? 1 : -1; });
    if (srcLogs.length > 1) {
      lines.push('');
      lines.push('  ── Історія останніх ' + srcLogs.length + ' сканувань ──');
      lines.push('  ' + padR('Час', 20) + padR('Статус', 14) + padR('Знайдено', 10) + padR('Нових', 7) + padR('Дублів', 7) + 'Помилка');
      lines.push('  ' + '─'.repeat(80));
      srcLogs.slice(0,20).forEach(function(l) {
        var errShort = (l.error||'').slice(0,40);
        lines.push('  ' +
          padR(gfFmtKyivDate(l.scanned_at || l.scanned_at_iso || ''), 20) +
          padR(l.status||'—', 14) +
          padR(String(l.raw_found||0), 10) +
          padR(String(l.created||0), 7) +
          padR(String(l.dupes||0), 7) +
          (errShort || '')
        );
      });
    }

    lines.push('  ' + '─'.repeat(70));
  });

  lines.push('');
  lines.push('══════════════════════════════════════════════════════════════════');
  lines.push('Кінець звіту · ' + now);
  lines.push('══════════════════════════════════════════════════════════════════');

  return lines.join('\n');
}

function padR(str, len) {
  str = String(str);
  return str.length >= len ? str.slice(0,len) : str + ' '.repeat(len - str.length);
}

/* ── Завантажує повний звіт файлом .txt ── */
async function gfDownloadFullReport() {
  var btn = document.getElementById('gfDownloadReportBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Збираю дані…'; }

  try {
    var sources = GF.data.sources || [];
    if (!sources.length) { gfToast('Немає джерел', 'var(--red)'); return; }

    // Завантажуємо останні логи всіх джерел (по 1 на джерело — останній)
    var logs = [];
    try {
      // Беремо останні 200 записів логів — охоплює більшість джерел
      var snap = await db.collection('gf_scan_logs')
        .orderBy('scanned_at', 'desc')
        .limit(500).get();
      if (!snap.empty) {
        snap.docs.forEach(function(d) { logs.push(d.data()); });
      }
    } catch(e) { /* ігноруємо — продовжуємо без повної історії */ }

    var text = gfBuildFullReport(sources, logs);

    // ── Завантажуємо файл ──
    var blob = new Blob(['\uFEFF' + text], { type: 'text/plain;charset=utf-8' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    var ts   = new Date().toLocaleString('sv-SE', {timeZone:'Europe/Kyiv'}).replace(/[\s:]/g,'-').slice(0,16);
    a.href     = url;
    a.download = 'kontrol-pro-report-' + ts + '.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    gfToast('Звіт завантажено (' + sources.length + ' джерел)', 'var(--green)');
  } catch(e) {
    gfToast('Помилка: ' + e.message, 'var(--red)');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '⬇ Завантажити звіт (.txt)'; }
  }
}

/* ── Відкрити звіт у новій вкладці (текстовий редактор браузера) ── */
async function gfOpenFullReportTab() {
  var btn = document.getElementById('gfOpenReportBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Збираю дані…'; }

  try {
    var sources = GF.data.sources || [];
    if (!sources.length) { gfToast('Немає джерел', 'var(--red)'); return; }

    var logs = [];
    try {
      var snap = await db.collection('gf_scan_logs')
        .orderBy('scanned_at', 'desc').limit(500).get();
      if (!snap.empty) snap.docs.forEach(function(d) { logs.push(d.data()); });
    } catch(e) {}

    var text = gfBuildFullReport(sources, logs);

    // Відкриваємо у новій вкладці як preformatted text
    var html = '<!DOCTYPE html><html><head><meta charset="utf-8">'
      + '<title>Kontrol Pro — Звіт парсингу</title>'
      + '<style>'
      + 'body{margin:0;background:#0b0f1a;color:#e2e8f0;font-family:\'Courier New\',monospace;font-size:12px;line-height:1.6;padding:16px}'
      + 'pre{white-space:pre-wrap;word-break:break-all}'
      + '.toolbar{position:sticky;top:0;background:#0f172a;border-bottom:1px solid #1e293b;padding:8px 16px;display:flex;gap:8px;z-index:10}'
      + 'button{background:#1e293b;border:1px solid #334155;color:#94a3b8;border-radius:6px;padding:5px 12px;cursor:pointer;font-size:11px}'
      + 'button:hover{background:#334155;color:#e2e8f0}'
      + '.err{color:#fca5a5}.ok{color:#86efac}.warn{color:#fde68a}.info{color:#93c5fd}.muted{color:#475569}'
      + '</style></head><body>'
      + '<div class="toolbar">'
      + '<button onclick="window.print()">🖨 Друк</button>'
      + '<button onclick="navigator.clipboard.writeText(document.querySelector(\'pre\').textContent).then(()=>this.textContent=\'✓ Скопійовано\')">📋 Копіювати все</button>'
      + '<button onclick="var t=document.querySelector(\'pre\').textContent;var b=new Blob([\'\\uFEFF\'+t],{type:\'text/plain;charset=utf-8\'});var a=document.createElement(\'a\');a.href=URL.createObjectURL(b);a.download=\'kontrol-report.txt\';a.click()">⬇ Зберегти файл</button>'
      + '<span style="margin-left:auto;color:#475569;font-size:11px">Kontrol Pro · ' + new Date().toLocaleString('uk-UA',{timeZone:'Europe/Kyiv'}) + '</span>'
      + '</div>'
      + '<pre>' + text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        // Підсвітка
        .replace(/(❌[^\n]*)/g,'<span class="err">$1</span>')
        .replace(/(✅[^\n]*)/g,'<span class="ok">$1</span>')
        .replace(/(⚠️[^\n]*|🚨[^\n]*)/g,'<span class="warn">$1</span>')
        .replace(/(♻️[^\n]*)/g,'<span class="muted">$1</span>')
        .replace(/(══[^\n]*)/g,'<span class="info">$1</span>')
      + '</pre></body></html>';

    var blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    var tabUrl = URL.createObjectURL(blob);
    window.open(tabUrl, '_blank');
    // URL revoke через 60 сек
    setTimeout(function() { URL.revokeObjectURL(tabUrl); }, 60000);

    gfToast('Звіт відкрито у новій вкладці', 'var(--green)');
  } catch(e) {
    gfToast('Помилка: ' + e.message, 'var(--red)');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '↗ Відкрити у вкладці'; }
  }
}

/* ── Копіювати короткий звіт про помилки в буфер ── */
function gfCopyErrorReport() {
  var src = GF.data.sources || [];
  var errSrc = src.filter(function(s) { return s.last_error || s.last_error_code; });
  if (!errSrc.length) { gfToast('Помилок немає', 'var(--green)'); return; }

  var lines = ['=== ЗВІТ ПО ПОМИЛКАХ ПАРСИНГУ ===',
               'Дата: ' + new Date().toLocaleString('uk-UA', {timeZone:'Europe/Kyiv'}), ''];
  errSrc.forEach(function(s) {
    lines.push('--- ' + (s.source_name||'?') + ' ---');
    lines.push('URL:     ' + (s.source_url||''));
    lines.push('Код:     ' + (s.last_error_code||'UNKNOWN'));
    lines.push('Тип:     ' + (s.last_error_label||'—'));
    lines.push('Помилка: ' + (s.last_error||''));
    var ll = s.last_scan_log || {};
    lines.push('Raw/after: ' + (ll.raw_found||0) + '/' + (ll.after_filter||0) + ' · >14д: ' + (ll.age_dropped||0) + ' · не UA: ' + (ll.non_ua_dropped||0) + ' · HTTP: ' + (ll.http_status||'—'));
    var lc = gfFmtKyivDate(s.last_checked_at_kyiv || s.last_checked_at || '');
    if (lc) lines.push('Час:     ' + lc);
    // Кроки з останнього логу
    var ll = s.last_scan_log || {};
    var steps = ll.diag_steps || [];
    if (steps.length) {
      lines.push('Кроки:');
      steps.forEach(function(st) {
        var d = Object.assign({},st); delete d.step; delete d.ts;
        lines.push('  [' + (st.ts||'') + '] ' + st.step + ': ' + JSON.stringify(d).slice(0,200));
      });
    }
    lines.push('');
  });

  navigator.clipboard.writeText(lines.join('\n')).then(function() {
    gfToast('Звіт скопійовано (' + errSrc.length + ' помилок)', 'var(--green)');
  }).catch(function() { gfToast('Помилка копіювання', 'var(--red)'); });
}

/* ═══════════════════════════════════════════════════════════
   КАТАЛОГ
   ═══════════════════════════════════════════════════════════ */
function gfViewCatalog(tabsH, existingSrc) {
  var existingIds  = existingSrc.map(function(s) { return (s.source_profile||s.source_name||'').toLowerCase(); });
  var existingUrls = existingSrc.map(function(s) { return (s.source_url||'').toLowerCase().replace(/\/+$/,''); });

  function isAdded(c) {
    return existingIds.indexOf(c.id.toLowerCase()) >= 0 ||
           existingUrls.indexOf(c.url.toLowerCase().replace(/\/+$/,'')) >= 0 ||
           existingSrc.some(function(s) { return (s.source_name||'').toLowerCase() === c.name.toLowerCase(); });
  }

  var cats = {};
  GF_CATALOG.forEach(function(c) { if (!cats[c.cat]) cats[c.cat] = []; cats[c.cat].push(c); });
  var addedCnt = GF_CATALOG.filter(isAdded).length;

  var h = '<div class="gf-panel"><div class="gf-panel-h"><h3>Каталог перевірених джерел</h3>'
    + '<div style="display:flex;gap:6px">'
    + '<span class="gf-badge blue">' + addedCnt + ' / ' + GF_CATALOG.length + ' додано</span>'
    + '<button class="gf-btn sm" onclick="gfBulkAddAll()">Додати ВСІ</button>'
    + '</div></div>' + tabsH
    + '<div class="gf-ok" style="margin-bottom:14px"><b>' + GF_CATALOG.length + ' перевірених джерел.</b> Натисніть «Додати» або «Додати ВСІ». Вже додані позначені ✓.</div>';

  Object.keys(cats).forEach(function(cat) {
    var items = cats[cat];
    var catIcon = cat.indexOf('Telegram') >= 0 ? '📱'
                : cat.indexOf('Google')   >= 0 ? '📰'
                : cat.indexOf('Міжнародні донори') >= 0 ? '🏛'
                : cat.indexOf('Міжнародні RSS')    >= 0 ? '🌍' : '🌐';
    h += '<div style="margin-bottom:16px">'
      + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--border)">'
      + '<span style="font-size:16px">' + catIcon + '</span>'
      + '<span style="font-size:13px;font-weight:700">' + gfE(cat) + '</span>'
      + '<span class="gf-badge gray">' + items.length + '</span></div>'
      + '<div class="gf-list" style="gap:6px">';
    items.forEach(function(c) {
      var added = isAdded(c);
      h += '<div class="gf-item" style="padding:10px 16px;display:flex;justify-content:space-between;align-items:center;gap:8px;' + (added ? 'opacity:.6' : '') + '"><div style="flex:1;min-width:0">'
        + '<div style="font-size:13px;font-weight:600">' + c.ico + ' ' + gfE(c.name) + '</div>'
        + '<div class="gf-muted" style="font-size:10px;word-break:break-all;margin-top:2px">' + gfE(c.url.slice(0,80)) + '</div>'
        + '</div><div>'
        + (added
          ? '<span class="gf-badge green">✓ Додано</span>'
          : '<button class="gf-btn sm" onclick="gfAddFromCatalog(\'' + gfE(c.id) + '\')">+ Додати</button>')
        + '</div></div>';
    });
    h += '</div></div>';
  });

  return h + '</div>';
}

/* ═══════════════════════════════════════════════════════════
   ПОШУК НОВИХ ДЖЕРЕЛ (DISCOVER)
   ═══════════════════════════════════════════════════════════ */
function gfViewDiscover(tabsH, existingSrc) {
  var existingUrls = new Set(existingSrc.map(function(s) {
    return (s.source_url||'').toLowerCase().replace(/\/+$/,'');
  }));
  var dismissed    = JSON.parse(localStorage.getItem('gf_discover_dismissed')||'[]');
  var dismissedSet = new Set(dismissed);

  // Збираємо зовнішні URL з виявлених грантів
  var det      = GF.data.detected || [];
  var urlCount = {}, urlTitles = {};

  det.forEach(function(d) {
    var u = (d.detail_url||'').toLowerCase().replace(/\/+$/,'');
    if (u && u.startsWith('http') && !u.includes('t.me')) {
      try {
        var host = new URL(u).hostname.replace(/^www\./,'');
        urlCount[host]  = (urlCount[host]||0) + 1;
        if (!urlTitles[host]) urlTitles[host] = [];
        if (urlTitles[host].length < 3) urlTitles[host].push(d.raw_title||'');
      } catch(e) {}
    }
    var srcUrl = (d.source_url||'').toLowerCase();
    if (srcUrl.includes('t.me')) {
      var m = srcUrl.match(/t\.me\/s?\/?([^\/\?]+)/);
      if (m) {
        var ch = 'telegram:' + m[1];
        urlCount[ch] = (urlCount[ch]||0) + 1;
        if (!urlTitles[ch]) urlTitles[ch] = [];
        if (urlTitles[ch].length < 3) urlTitles[ch].push(d.raw_title||'');
      }
    }
  });

  var candidates = Object.keys(urlCount)
    .filter(function(h) {
      if (dismissedSet.has(h)) return false;
      return !existingSrc.some(function(s) {
        var su = (s.source_url||'').toLowerCase();
        return su.includes(h) || (h.startsWith('telegram:') && su.includes(h.replace('telegram:','')));
      });
    })
    .sort(function(a,b) { return urlCount[b] - urlCount[a]; })
    .slice(0, 50);

  var h = '<div class="gf-panel"><div class="gf-panel-h"><h3>🔎 Нові джерела</h3>'
    + '<span class="gf-badge blue">' + candidates.length + ' кандидатів</span></div>'
    + tabsH
    + '<div class="gf-ok" style="margin-bottom:14px">Сайти та канали, які найчастіше зустрічаються у виявлених грантах. Вже додані як джерела — не показуються.</div>';

  if (!candidates.length) {
    return h + '<div class="gf-empty">Немає нових кандидатів. Накопичіть більше виявлених записів або додайте джерела вручну.</div></div>';
  }

  h += '<div class="gf-list">';
  candidates.forEach(function(host) {
    var cnt    = urlCount[host];
    var titles = (urlTitles[host]||[]).slice(0,2);
    var isTg   = host.startsWith('telegram:');
    var channel    = isTg ? host.replace('telegram:','') : '';
    var displayUrl = isTg ? 'https://t.me/s/' + channel : 'https://' + host;
    var ico        = isTg ? '📱' : '🌐';

    h += '<div class="gf-item" style="padding:10px 16px">'
      + '<div style="display:flex;align-items:center;gap:10px">'
      + '<div style="min-width:38px;height:38px;background:rgba(79,110,247,.15);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:800;color:#4f6ef7;flex-shrink:0">' + cnt + '</div>'
      + '<div style="flex:1;min-width:0">'
      + '<div style="font-size:13px;font-weight:600">' + ico + ' ' + gfE(isTg ? '@'+channel : host) + '</div>'
      + '<div class="gf-muted" style="font-size:10px;margin-top:2px;word-break:break-all">' + gfE(displayUrl) + '</div>'
      + (titles.length ? '<div style="font-size:11px;color:#64748b;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'
          + titles.map(function(t){return gfE(t.slice(0,60));}).join(' · ') + '</div>' : '')
      + '</div>'
      + '<div style="display:flex;gap:4px;flex-shrink:0">'
      + '<button class="gf-btn sm o" title="Відкрити" data-disc-open="' + gfE(displayUrl) + '">↗</button>'
      + '<button class="gf-btn sm g" title="Додати як джерело" data-disc-host="' + gfE(host) + '" data-disc-url="' + gfE(displayUrl) + '" data-disc-name="' + gfE(isTg?'@'+channel:host) + '">+ Додати</button>'
      + '<button class="gf-btn sm r" title="Вилучити" data-disc-dismiss="' + gfE(host) + '">✕</button>'
      + '</div></div></div>';
  });
  h += '</div>';

  if (dismissed.length) {
    h += '<div style="margin-top:16px;border-top:1px solid rgba(255,255,255,.08);padding-top:14px">'
      + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'
      + '<div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.4px">Вилучені (' + dismissed.length + ')</div>'
      + '<button class="gf-btn sm o" style="font-size:10px" data-disc-restore>↺ Відновити всі</button>'
      + '</div>'
      + '<div class="gf-list" style="gap:4px">';
    dismissed.forEach(function(dhost) {
      var dcnt = urlCount[dhost] || 0;
      var disTg = dhost.startsWith('telegram:');
      var dLabel = disTg ? '@' + dhost.replace('telegram:','') : dhost;
      h += '<div class="gf-item" style="padding:7px 14px;opacity:.5;display:flex;align-items:center;gap:8px">'
        + '<div style="min-width:28px;text-align:center;font-size:12px;font-weight:700;color:#64748b">' + dcnt + '</div>'
        + '<div style="flex:1;font-size:12px;color:#64748b">' + (disTg?'📱':'🌐') + ' ' + gfE(dLabel) + '</div>'
        + '<button class="gf-btn sm o" style="font-size:10px;padding:3px 8px" data-disc-restore-one="' + gfE(dhost) + '">↺</button>'
        + '</div>';
    });
    h += '</div></div>';
  }

  return h + '</div>';
}

/* ═══════════════════════════════════════════════════════════
   ЛОГ СКАНУВАННЯ (МОДАЛКА)
   ═══════════════════════════════════════════════════════════ */
async function gfShowScanLog(sourceId, sourceName) {
  var modal = document.createElement('div');
  modal.id = 'gfScanLogModal_' + sourceId;
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(11,15,26,.92);backdrop-filter:blur(6px);z-index:20000;display:flex;align-items:center;justify-content:center;padding:16px';
  modal.innerHTML = '<div style="width:min(900px,96vw);max-height:92vh;overflow-y:auto;background:#0f172a;border:1px solid rgba(255,255,255,.15);border-radius:14px;padding:22px;color:#e2e8f0;font-family:Geologica,sans-serif">'
    + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">'
    + '<h3 style="margin:0;font-size:15px">📋 Лог сканування: ' + gfE(sourceName) + '</h3>'
    + '<div style="display:flex;gap:8px">'
    + '<button id="gfLogHealthBtn" style="background:#1e293b;border:1px solid rgba(255,255,255,.1);color:#94a3b8;border-radius:8px;padding:5px 12px;cursor:pointer;font-size:11px">🩺 Health check</button>'
    + '<button id="gfLogCopyBtn" style="background:#1e293b;border:1px solid rgba(255,255,255,.1);color:#94a3b8;border-radius:8px;padding:5px 12px;cursor:pointer;font-size:11px">📋 Копіювати лог</button>'
    + '<button id="gfLogCloseBtn" style="background:#ef4444;border:none;color:#fff;border-radius:8px;padding:5px 14px;cursor:pointer;font-weight:700;font-size:13px">✕</button>'
    + '</div></div>'
    + '<div id="gfLogBody" style="font-size:12px">Завантаження…</div></div>';
  document.body.appendChild(modal);

  // Кнопка закрити — через id, без onclick escaping
  document.getElementById('gfLogCloseBtn').addEventListener('click', function() {
    var m = document.getElementById('gfScanLogModal_' + sourceId);
    if (m) m.remove();
  });
  // Закрити по кліку на фон
  modal.addEventListener('click', function(e) {
    if (e.target === modal) modal.remove();
  });

  try {
    var snap = await db.collection('gf_scan_logs')
      .where('source_id','==',sourceId)
      .orderBy('scanned_at','desc')
      .limit(30).get();

    var body = document.getElementById('gfLogBody');
    if (!body) return;

    var logDocs = [];
    if (snap.empty) {
      // Fallback: last_scan_log з документа джерела
      var srcSnap = await db.collection('gf_sources').doc(sourceId).get();
      var srcData = srcSnap.exists ? srcSnap.data() : {};
      var ll = srcData.last_scan_log;
      if (!ll) {
        body.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px">Лог ще порожній. Дані з\'являться після наступного сканування.</div>';
        return;
      }
      logDocs = [ll];
    } else {
      logDocs = snap.docs.map(function(d){ return d.data(); });
    }

    // Кнопка "Health check"
    var healthBtn = document.getElementById('gfLogHealthBtn');
    if (healthBtn && logDocs.length) {
      var srcUrl = logDocs[0].source_url || '';
      if (srcUrl) {
        healthBtn.onclick = async function() {
          healthBtn.disabled = true; healthBtn.textContent = '⏳…';
          try {
            var CF_URL = 'https://us-central1-kontrol-pro.cloudfunctions.net/healthCheck';
            var r = await fetch(CF_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ url: srcUrl }) });
            var hd = await r.json();
            var color = hd.status >= 200 && hd.status < 300 ? '#10b981' : '#ef4444';
            gfToast('🩺 ' + srcUrl.slice(0,40) + ' → HTTP ' + (hd.status||'timeout') + ' | ' + hd.ms + 'ms | ' + Math.round((hd.size||0)/1024) + 'KB', color);
          } catch(e) { gfToast('❌ ' + e.message, '#ef4444'); }
          finally { healthBtn.disabled = false; healthBtn.textContent = '🩺 Health check'; }
        };
      } else { healthBtn.style.display = 'none'; }
    }

    // Кнопка "Копіювати лог"
    var copyBtn = document.getElementById('gfLogCopyBtn');
    if (copyBtn) {
      copyBtn.onclick = function() {
        var txt = logDocs.map(function(l){
          return ['=== ' + gfFmtKyivDate(l.scanned_at || l.scanned_at_iso || '') + ' | ' + (l.status||'') + ' ===',
                  'Знайдено: '+(l.raw_found||0)+' | Фільтр: '+(l.after_filter||0)+' | Нових: '+(l.created||0)+' | Дублів: '+(l.dupes||0),
                  l.error ? '❌ ПОМИЛКА: ' + l.error : '',
                  (l.diag_warnings||[]).length ? 'Попередження:\n' + l.diag_warnings.join('\n') : '',
                  (l.diag_steps||[]).length ? 'Кроки:\n' + l.diag_steps.map(function(s){return '['+s.ts+'] '+s.step+': '+JSON.stringify(s);}).join('\n') : ''
          ].filter(Boolean).join('\n');
        }).join('\n\n');
        navigator.clipboard.writeText(txt).then(function(){
          copyBtn.textContent = '✓ Скопійовано'; setTimeout(function(){copyBtn.textContent='📋 Копіювати лог';},2000);
        });
      };
    }

    var rows = '';
    logDocs.forEach(function(l) {
      var st = l.status || '';
      var stColor  = st==='ok_new'?'#10b981':st==='ok_dupes'?'#4f6ef7':st==='filtered'?'#f59e0b':st==='error'?'#ef4444':'#64748b';
      var stIcon   = st==='ok_new'?'✅':st==='ok_dupes'?'♻️':st==='filtered'?'⚠️':st==='error'?'❌':st==='empty'?'📭':'—';
      var stLabel  = st==='ok_new'?'Нові записи':st==='ok_dupes'?'Лише дублікати':st==='filtered'?'Відфільтровано':st==='error'?'Помилка':st==='empty'?'Порожня відповідь':'—';

      // Витягуємо HTTP-статус з кроків діагностики
      var httpStep = (l.diag_steps||[]).find(function(s){ return s.step === 'rss_fetch'; });
      var httpStatus = httpStep ? httpStep.http_status : null;
      var httpBadge = httpStatus
        ? '<span style="background:' + (httpStatus >= 200 && httpStatus < 300 ? 'rgba(16,185,129,.15)' : 'rgba(239,68,68,.15)') + ';color:' + (httpStatus >= 200 && httpStatus < 300 ? '#10b981' : '#ef4444') + ';padding:1px 6px;border-radius:4px;font-size:10px;margin-left:6px">HTTP ' + httpStatus + '</span>'
        : '';

      // ── Діагностичні кроки ──
      var diagHtml = '';
      if (l.diag_steps && l.diag_steps.length) {
        // Мітки для кроків
        var STEP_LABELS = {
          'start':              '🚀 Старт сканування',
          'rss_fetch':          '🌐 HTTP запит',
          'rss_fetch_retry':    '🔄 Retry з іншим UA',
          'rss_fetch_done':     '✅ Відповідь отримано',
          'rss_channel':        '📡 RSS канал',
          'rss_atom_feed':      '📡 Atom фід',
          'rss_entries_total':  '📋 Всього записів у фіді',
          'rss_all_outside_window': '⏰ Всі записи поза вікном дат',
          'rss_unknown_structure':  '⚠️ Невідома XML структура',
          'rss_parse_error':    '❌ Помилка XML парсингу',
          'parsed':             '✅ Розпарсено',
          'rss_retry_14d':      '🔁 Retry 14 днів',
          'rss_retry_14d_empty':'🔁 Retry 14д — порожньо',
          'cache_check':        '🗄️ Перевірка URL-кешу',
          'tg_multi':           '📨 TG мульти-пост розбито',
          'multi_grant':        '📦 Мультиграм',
          'multi_grant_error':  '❌ Помилка мультиграм',
          'filter':             '🔍 Фільтрація',
          'result':             '🏁 Результат',
          'parse_error':        '❌ Помилка парсингу'
        };
        // Визначаємо чи є retry-кроки
        var hasRetry = l.diag_steps.some(function(s){ return (s.step||'').indexOf('retry') >= 0; });
        var hasFetch = l.diag_steps.some(function(s){ return s.step === 'rss_fetch'; });

        diagHtml += '<details ' + (l.status==='error'||hasFetch?'open':'') + ' style="margin-top:10px">'
          + '<summary style="font-size:10px;font-weight:700;color:#64748b;cursor:pointer;text-transform:uppercase;letter-spacing:.5px">Кроки діагностики (' + l.diag_steps.length + ')'
          + (hasRetry ? ' <span style="color:#f59e0b;font-size:9px">⚡ автоповтор</span>' : '')
          + '</summary>'
          + '<div style="margin-top:6px;border-top:1px solid rgba(255,255,255,.06);padding-top:6px">';

        l.diag_steps.forEach(function(step) {
          var sName  = step.step || '';
          var isErr  = sName === 'parse_error' || sName === 'multi_grant_error' || sName === 'rss_parse_error' || sName.indexOf('error') >= 0;
          var isWarn = sName.indexOf('outside_window') >= 0 || sName.indexOf('retry_empty') >= 0 || sName.indexOf('unknown') >= 0;
          var isDone = sName === 'result';
          var isFetch = sName === 'rss_fetch';
          var stepColor = isErr ? '#ef4444' : isDone ? '#10b981' : isWarn ? '#f59e0b' : isFetch ? '#4f6ef7' : '#94a3b8';
          var label  = STEP_LABELS[sName] || sName;

          // Спеціальне відображення для rss_fetch
          var extraHtml = '';
          if (sName === 'rss_fetch') {
            var sc = step.http_status;
            var scColor = sc >= 200 && sc < 300 ? '#10b981' : sc >= 400 ? '#ef4444' : '#f59e0b';
            extraHtml = '<span style="color:' + scColor + ';font-weight:700">HTTP ' + (sc||'?') + '</span>'
              + ' | ' + gfE(step.content_type || '—');
          } else if (sName === 'rss_fetch_retry') {
            extraHtml = '<span style="color:#f59e0b">HTTP ' + step.http_status + ' → спроба ' + (step.next_attempt + 1) + '</span>';
          } else if (sName === 'rss_fetch_done') {
            var sc2 = step.http_status;
            var sc2Color = sc2 >= 200 && sc2 < 300 ? '#10b981' : '#ef4444';
            extraHtml = '<span style="color:' + sc2Color + '">HTTP ' + sc2 + '</span>'
              + ' | ' + Math.round((step.response_size||0)/1024) + ' KB';
          } else if (sName === 'rss_channel' || sName === 'rss_atom_feed') {
            extraHtml = '"' + gfE((step.channel_title||step.feed_title||'').slice(0,60)) + '" | '
              + (step.total_items||0) + ' записів у фіді';
          } else if (sName === 'rss_entries_total') {
            extraHtml = (step.count||0) + ' записів';
          } else if (sName === 'rss_all_outside_window') {
            extraHtml = 'вікно ' + step.window_days + ' дн. | дати у фіді: '
              + ((step.sample_dates||[]).join(', ') || '—');
          } else if (sName === 'rss_unknown_structure') {
            extraHtml = 'Ключі: ' + gfE(step.keys||'') + '<br><span style="color:#475569">' + gfE((step.xml_preview||'').slice(0,120)) + '</span>';
          } else if (sName === 'cache_check') {
            extraHtml = 'перевірено URL: ' + (step.urls_to_check||0);
          } else if (sName === 'rss_retry_14d') {
            extraHtml = 'знайдено за 14 днів: <b>' + step.raw_count + '</b>';
          } else if (sName === 'rss_retry_14d_empty') {
            extraHtml = '<span style="color:#f59e0b">Фід порожній навіть за 14 днів</span>';
          } else if (sName === 'rss_retry_wider_window') {
            extraHtml = '🔁 вікно розширено до <b style="color:#f59e0b">' + step.window_days + ' днів</b> → знайдено ' + step.raw_count;
          } else if (sName === 'parsed') {
            extraHtml = 'знайдено: <b>' + step.raw_count + '</b>'
              + (step.multi_blocks > 0
                ? ' | з них з мульти-постів: <b style="color:#4f6ef7">' + step.multi_blocks + '</b>'
                : '')
              + (step.sample_titles && step.sample_titles.length
                ? ' | ' + step.sample_titles.map(function(t){ return '"' + gfE(t) + '"'; }).join(', ')
                : '');
          } else if (sName === 'filter') {
            extraHtml = 'сирих: ' + step.raw + ' → пройшло: <b style="color:#10b981">' + step.passed + '</b>'
              + ' | відфільтровано: ' + step.filtered
              + (step.relaxed_mode ? ' <span style="color:#f59e0b;font-size:9px">[relaxed]</span>' : '')
              + (step.filtered_samples && step.filtered_samples.length
                ? '<div style="color:#475569;font-size:9px;margin-top:1px">відкинуто: ' + step.filtered_samples.map(function(s){return gfE(s);}).join(', ') + '</div>'
                : '');
          } else if (sName === 'result') {
            extraHtml = '🆕 нових: <b style="color:#10b981">' + step.created + '</b>'
              + ' | дублів: ' + step.dupes
              + ' | деталей: ' + step.detailed
              + (step.is_multi ? ' | <span style="color:#4f6ef7">мульти</span>' : '');
          } else if (sName === 'multi_grant') {
            extraHtml = 'блоків: ' + step.blocks_found + ' | додано: ' + step.added;
          } else if (isErr) {
            var errLabel = step.error_label ? '<span style="color:#f59e0b;font-weight:700">' + gfE(step.error_label) + '</span> · ' : '';
            var retriable = step.retriable === false
              ? '<span style="color:#ef4444;font-size:9px">не повторювати</span>'
              : step.retriable === true ? '<span style="color:#10b981;font-size:9px">можна повторити</span>' : '';
            extraHtml = errLabel
              + '<span style="color:#fca5a5">' + gfE((step.error||'').slice(0,200)) + '</span>'
              + (retriable ? ' ' + retriable : '')
              + (step.stack ? '<div style="color:#475569;font-size:9px;margin-top:2px">' + gfE(step.stack.slice(0,200)) + '</div>' : '');
          } else {
            var stepData = Object.assign({}, step);
            delete stepData.step; delete stepData.ts;
            extraHtml = '<span style="color:#475569">' + gfE(JSON.stringify(stepData).slice(0, 200)) + '</span>';
          }

          diagHtml += '<div style="display:flex;gap:8px;margin-bottom:4px;font-size:11px;align-items:flex-start">'
            + '<span style="color:#4f6ef7;min-width:60px;flex-shrink:0;font-size:10px">' + gfE(step.ts||'') + '</span>'
            + '<span style="color:' + stepColor + ';min-width:180px;flex-shrink:0;font-weight:600">' + label + '</span>'
            + '<span style="word-break:break-all;line-height:1.4">' + extraHtml + '</span>'
            + '</div>';
        });
        diagHtml += '</div></details>';
      }

      // ── Попередження / дублі ──
      var warnHtml = '';
      var warnings = l.diag_warnings || [];
      if (warnings.length) {
        var errWarn  = warnings.filter(function(w){ return w.startsWith('Fatal') || w.startsWith('Parse failed'); });
        var dupWarn  = warnings.filter(function(w){ return w.startsWith('dup_'); });
        var restWarn = warnings.filter(function(w){ return !w.startsWith('Fatal') && !w.startsWith('Parse failed') && !w.startsWith('dup_'); });

        warnHtml += '<div style="margin-top:8px">';
        if (errWarn.length) {
          warnHtml += '<div style="padding:8px;background:rgba(239,68,68,.1);border-radius:6px;margin-bottom:6px">'
            + '<div style="font-size:10px;font-weight:700;color:#ef4444;margin-bottom:4px">🚨 Критичні помилки (' + errWarn.length + ')</div>'
            + errWarn.map(function(w){return '<div style="font-size:10px;color:#fca5a5;word-break:break-all;margin-bottom:2px">' + gfE(w) + '</div>';}).join('')
            + '</div>';
        }
        if (dupWarn.length) {
          // Розбивка дублів за типом
          var dupCache   = dupWarn.filter(function(w){ return w.startsWith('dup_cache'); });
          var dupUrl     = dupWarn.filter(function(w){ return w.startsWith('dup_url'); });
          var dupTitle   = dupWarn.filter(function(w){ return w.startsWith('dup_title'); });
          var dupFp      = dupWarn.filter(function(w){ return w.startsWith('dup_fp'); });
          var dupDetail  = dupWarn.filter(function(w){ return w.startsWith('dup_detail'); });
          var dupSummary = [];
          if (dupCache.length)  dupSummary.push('🗄️ кеш: ' + dupCache.length);
          if (dupUrl.length)    dupSummary.push('🔗 URL: ' + dupUrl.length);
          if (dupTitle.length)  dupSummary.push('📝 заголовок: ' + dupTitle.length);
          if (dupFp.length)     dupSummary.push('🔍 fingerprint: ' + dupFp.length);
          if (dupDetail.length) dupSummary.push('🔀 cross-detail: ' + dupDetail.length);

          warnHtml += '<details style="margin-bottom:6px"><summary style="font-size:10px;font-weight:700;color:#64748b;cursor:pointer">'
            + 'Дублікати пропущено (' + dupWarn.length + ')'
            + (dupSummary.length ? ' — <span style="font-weight:400">' + dupSummary.join(', ') + '</span>' : '')
            + '</summary>'
            + '<div style="margin-top:4px;padding:6px 8px;background:rgba(255,255,255,.03);border-radius:6px">'
            + dupWarn.slice(0,30).map(function(w){
                var typeColor = w.startsWith('dup_cache')  ? '#4f6ef7'
                              : w.startsWith('dup_detail') ? '#f59e0b'
                              : '#64748b';
                return '<div style="font-size:10px;color:' + typeColor + ';word-break:break-all;margin-bottom:1px">' + gfE(w) + '</div>';
              }).join('')
            + (dupWarn.length > 30 ? '<div style="font-size:10px;color:#475569">…ще ' + (dupWarn.length-30) + '</div>' : '')
            + '</div></details>';
        }
        if (restWarn.length) {
          warnHtml += '<details><summary style="font-size:10px;font-weight:700;color:#f59e0b;cursor:pointer">⚠️ Інші попередження (' + restWarn.length + ')</summary>'
            + '<div style="margin-top:4px;padding:6px 8px;background:rgba(245,158,11,.06);border-radius:6px">'
            + restWarn.slice(0,20).map(function(w){return '<div style="font-size:10px;color:#94a3b8;word-break:break-all;margin-bottom:2px">' + gfE(w) + '</div>';}).join('')
            + '</div></details>';
        }
        warnHtml += '</div>';
      }

      rows += '<div style="border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:12px;margin-bottom:8px;background:rgba(255,255,255,.02)">'
        + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'
        + '<div style="display:flex;align-items:center;gap:6px">'
        + '<span style="color:' + stColor + ';font-weight:700">' + stIcon + ' ' + stLabel + '</span>'
        + httpBadge
        + '</div>'
        + '<span style="color:#64748b;font-size:11px">' + gfFmtKyivDate(l.scanned_at || l.scanned_at_iso || '') + '</span>'
        + '</div>'
        + '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:8px">'
        + gfLogCell('Знайдено',    l.raw_found||0,    '#94a3b8')
        + gfLogCell('Після фільтру', l.after_filter||0, '#94a3b8')
        + gfLogCell('Нових',       l.created||0,      l.created>0?'#10b981':'#94a3b8')
        + gfLogCell('Дублів',      l.dupes||0,        '#94a3b8')
        + gfLogCell('Деталі',      l.detailed||0,     '#64748b')
        + '</div>'
        + '<div style="display:flex;gap:6px;flex-wrap:wrap;font-size:10px">'
        + '<span style="background:rgba(255,255,255,.06);padding:2px 8px;border-radius:4px">Парсер: ' + gfE(l.parser_mode||'—') + '</span>'
        + '<span style="background:rgba(255,255,255,.06);padding:2px 8px;border-radius:4px">Вікно: ' + gfE(l.window_days||7) + ' дн</span>'
        + (l.is_multi ? '<span style="background:rgba(79,110,247,.15);color:#4f6ef7;padding:2px 8px;border-radius:4px">Мульти-грант</span>' : '')
        + '</div>'
        + (l.error ? '<div style="margin-top:8px;padding:8px;background:rgba(239,68,68,.1);border-radius:6px;color:#ef4444;font-size:11px;word-break:break-all">❌ ' + gfE(l.error) + '</div>' : '')
        + diagHtml + warnHtml
        + '</div>';
    });

    body.innerHTML = rows || '<div style="color:#64748b;text-align:center;padding:20px">Немає записів.</div>';
  } catch(e) {
    var body2 = document.getElementById('gfLogBody');
    if (body2) body2.innerHTML = '<div style="color:#ef4444;padding:12px">Помилка завантаження лога: ' + gfE(e.message) + '<br><br>'
      + '<small style="color:#94a3b8">Перевірте: колекція <b>gf_scan_logs</b> повинна мати складений індекс Firestore:<br>'
      + 'Поля: <b>source_id (asc)</b> + <b>scanned_at (desc)</b></small></div>';
  }
}

function gfLogCell(label, val, color) {
  return '<div style="background:rgba(255,255,255,.04);border-radius:6px;padding:6px;text-align:center">'
    + '<div style="font-size:16px;font-weight:800;color:' + color + '">' + val + '</div>'
    + '<div style="font-size:10px;color:#64748b;margin-top:1px">' + label + '</div></div>';
}

/* ═══════════════════════════════════════════════════════════
   ПРИМУСОВЕ СКАНУВАННЯ ДЖЕРЕЛА
   ═══════════════════════════════════════════════════════════ */
async function gfForceScan(sourceId, sourceName) {
  // Знаходимо кнопку Скан для цього джерела
  var scanBtn = null;
  document.querySelectorAll('.gf-btn').forEach(function(b) {
    var oc = b.getAttribute('onclick') || '';
    if (oc.indexOf('gfForceScan') >= 0 && oc.indexOf(sourceId) >= 0) scanBtn = b;
  });
  if (scanBtn) { scanBtn.disabled = true; scanBtn.textContent = '⏳…'; }

  gfToast('🔄 Сканую: ' + sourceName + '…', '#4f6ef7');

  try {
    var CF_URL = GFC && GFC.fnBase ? (GFC.fnBase + 'scanSource') : 'https://us-central1-kontrol-pro.cloudfunctions.net/scanSource';
    var resp = await fetch(CF_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceId: sourceId })
    });
    var result = await resp.json();

    if (result.error) {
      gfToast('❌ ' + result.error, '#ef4444');
    } else {
      var diag = result.diag || {};
      var warnings = (diag.warnings || []).filter(function(w){ return !w.startsWith('dup_'); });
      var msg = '✅ ' + sourceName + ': знайдено ' + (result.checked||0)
        + ', нових ' + (result.created||0)
        + ', дублів ' + (result.dupes||0)
        + (warnings.length ? ' ⚠️ ' + warnings.length + ' попереджень' : '');
      gfToast(msg, result.created > 0 ? '#10b981' : '#4f6ef7');
      await gfRefresh();
    }
  } catch(e) {
    gfToast('❌ Помилка: ' + e.message, '#ef4444');
  } finally {
    if (scanBtn) { scanBtn.disabled = false; scanBtn.textContent = '▶ Скан'; }
  }
}

function gfScanStatusLabel(result) {
  if (!result) return 'error';
  if (result.error) return 'error';
  if ((result.created||0) > 0) return 'ok_new';
  if ((result.dupes||0) > 0 && (result.passed||0) > 0) return 'ok_dupes';
  if ((result.checked||0) > 0) return 'filtered';
  return 'empty';
}

function gfBulkScanEnsureModal() {
  var ex = document.getElementById('gfBulkScanModal');
  if (ex) return ex;
  var el = document.createElement('div');
  el.id = 'gfBulkScanModal';
  el.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(2,6,23,.78);z-index:9999;padding:20px;overflow:auto';
  el.innerHTML = ''
    + '<div style="max-width:860px;margin:0 auto;background:#0f172a;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:16px;box-shadow:0 20px 60px rgba(0,0,0,.45)">'
    + '<div style="display:flex;align-items:center;gap:10px;justify-content:space-between;margin-bottom:12px">'
    + '<div><div style="font-size:18px;font-weight:800;color:#e2e8f0">Масове сканування джерел</div><div id="gfBulkScanSub" style="font-size:12px;color:#94a3b8">Підготовка…</div></div>'
    + '<div style="display:flex;gap:8px">'
    + '<button class="gf-btn sm o" onclick="gfBulkScanStop()">⏹ Зупинити</button>'
    + '<button class="gf-btn sm" onclick="document.getElementById(\'gfBulkScanModal\').style.display=\'none\'">✕ Закрити</button>'
    + '</div></div>'
    + '<div style="height:14px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden">'
    + '<div id="gfBulkScanBar" style="height:100%;width:0%;background:linear-gradient(90deg,#4f46e5,#10b981);transition:width .25s"></div></div>'
    + '<div id="gfBulkScanStats" style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-top:12px"></div>'
    + '<div id="gfBulkScanCurrent" style="margin-top:12px;font-size:13px;color:#e2e8f0"></div>'
    + '<div id="gfBulkScanLog" style="margin-top:14px;max-height:420px;overflow:auto;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:10px;background:rgba(255,255,255,.03)"></div>'
    + '</div>';
  document.body.appendChild(el);
  return el;
}

function gfBulkScanRender() {
  var st = GF.bulkScanState || {};
  var modal = gfBulkScanEnsureModal();
  modal.style.display = 'block';
  var total = st.total || 0;
  var processed = st.processed || 0;
  var pct = total ? Math.round(processed / total * 100) : 0;
  var sub = document.getElementById('gfBulkScanSub');
  var bar = document.getElementById('gfBulkScanBar');
  var stats = document.getElementById('gfBulkScanStats');
  var current = document.getElementById('gfBulkScanCurrent');
  var log = document.getElementById('gfBulkScanLog');
  if (sub) sub.textContent = (st.running ? 'Виконується… ' : 'Завершено. ') + processed + ' / ' + total + ' · ' + pct + '%';
  if (bar) bar.style.width = pct + '%';
  if (stats) {
    stats.innerHTML = [
      gfLogCell('Опрацьовано', processed + '/' + total, '#93c5fd'),
      gfLogCell('Нових', st.created || 0, '#10b981'),
      gfLogCell('Дублів', st.dupes || 0, '#f59e0b'),
      gfLogCell('Помилок', st.errors || 0, '#ef4444'),
      gfLogCell('>14 днів', st.ageDropped || 0, '#fb7185'),
      gfLogCell('Не UA', st.nonUaDropped || 0, '#f97316')
    ].join('');
  }
  if (current) current.innerHTML = st.current ? ('<b>Зараз:</b> ' + gfE(st.current)) : '';
  if (log) {
    var rows = (st.items || []).slice().reverse().map(function(it) {
      var color = it.status === 'ok_new' ? '#10b981' : it.status === 'error' ? '#ef4444' : it.status === 'filtered' ? '#f59e0b' : '#93c5fd';
      return '<div style="display:grid;grid-template-columns:74px 1.6fr repeat(6,minmax(52px,.55fr));gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06)">'
        + '<div style="color:#64748b;font-size:11px">' + gfE(it.time || '') + '</div>'
        + '<div style="color:#e2e8f0;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + gfE(it.name || '') + '</div>'
        + '<div style="color:' + color + ';font-size:11px">' + gfE(it.status || '') + '</div>'
        + '<div style="font-size:11px;color:#cbd5e1">raw ' + (it.checked || 0) + '</div>'
        + '<div style="font-size:11px;color:#10b981">new ' + (it.created || 0) + '</div>'
        + '<div style="font-size:11px;color:#f59e0b">dup ' + (it.dupes || 0) + '</div>'
        + '<div style="font-size:11px;color:#fb7185">old ' + (it.ageDropped || 0) + '</div>'
        + '<div style="font-size:11px;color:#f97316">nonUA ' + (it.nonUaDropped || 0) + '</div>'
        + '</div>';
    });
    log.innerHTML = rows.length ? rows.join('') : '<div style="color:#64748b;font-size:12px">Ще немає результатів…</div>';
  }
}

function gfBulkScanStop() {
  if (!GF.bulkScanState) GF.bulkScanState = {};
  GF.bulkScanState.stop = true;
  gfToast('⏹ Зупинка після поточного джерела…', '#f59e0b');
  gfBulkScanRender();
}

async function gfBulkScanAll() {
  var activeSources = (GF.data.sources || []).filter(function(s){ return s.source_status === 'active'; });
  if (!activeSources.length) { gfToast('Немає активних джерел', 'var(--red)'); return; }
  if (GF.bulkScanState && GF.bulkScanState.running) { gfBulkScanEnsureModal().style.display = 'block'; return; }
  if (!confirm('Запустити масове сканування ' + activeSources.length + ' активних джерел?')) return;

  GF.bulkScanState = {
    running: true, stop: false, total: activeSources.length, processed: 0, created: 0, dupes: 0, errors: 0, ageDropped: 0, nonUaDropped: 0, current: '', items: [], startedAt: Date.now()
  };
  gfBulkScanRender();

  var CF_URL = GFC && GFC.fnBase ? (GFC.fnBase + 'scanSource') : 'https://us-central1-kontrol-pro.cloudfunctions.net/scanSource';

  for (var i = 0; i < activeSources.length; i++) {
    var s = activeSources[i];
    if (GF.bulkScanState.stop) break;
    GF.bulkScanState.current = s.source_name || ('Джерело ' + (i + 1));
    gfBulkScanRender();

    var itemResult = {
      time: new Date().toLocaleTimeString('uk-UA', { hour:'2-digit', minute:'2-digit', second:'2-digit', timeZone:'Europe/Kyiv' }),
      name: s.source_name || '?', status: 'error', checked: 0, created: 0, dupes: 0, ageDropped: 0, nonUaDropped: 0
    };

    try {
      var resp = await fetch(CF_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceId: s._id || s.source_id })
      });
      var result = await resp.json();
      if (!resp.ok || result.error) throw new Error(result.error || ('HTTP ' + resp.status));

      var gate = ((result.diag || {}).steps || []).find(function(st){ return st.step === 'selection_gates'; }) || {};
      itemResult.status = gfScanStatusLabel(result);
      itemResult.checked = result.checked || 0;
      itemResult.created = result.created || 0;
      itemResult.dupes = result.dupes || 0;
      itemResult.ageDropped = gate.age_dropped || 0;
      itemResult.nonUaDropped = gate.non_ua_dropped || 0;

      GF.bulkScanState.created += itemResult.created;
      GF.bulkScanState.dupes += itemResult.dupes;
      GF.bulkScanState.ageDropped += itemResult.ageDropped;
      GF.bulkScanState.nonUaDropped += itemResult.nonUaDropped;
    } catch (e) {
      itemResult.status = 'error';
      itemResult.error = e.message;
      GF.bulkScanState.errors += 1;
    }

    GF.bulkScanState.items.push(itemResult);
    GF.bulkScanState.processed += 1;
    gfBulkScanRender();
  }

  GF.bulkScanState.running = false;
  GF.bulkScanState.current = GF.bulkScanState.stop ? 'Зупинено користувачем' : 'Готово';
  gfBulkScanRender();
  await gfRefresh();
  gfRender();
  gfToast('✅ Масове сканування завершено: ' + GF.bulkScanState.processed + ' / ' + GF.bulkScanState.total, 'var(--green)');
}

/* ═══════════════════════════════════════════════════════════
   ACTIONS
   ═══════════════════════════════════════════════════════════ */
function gfSrcDoSearch() {
  GF.sourceSearch = (gfId('gfSrcSearch')||{}).value || '';
  gfRender();
}

async function gfAddSrcFromUrl() {
  var url  = (gfId('gfNewSrcUrl')||{}).value  || '';
  var name = (gfId('gfNewSrcName')||{}).value || '';
  if (!url.trim()) { alert('Введи URL'); return; }
  var isTg   = /t\.me/i.test(url);
  var isRss  = /\/feed|rss|\.xml/i.test(url);
  var isNews = /news\.google/i.test(url);
  if (!name) {
    var m = url.match(/https?:\/\/([^\/]+)/);
    name = m ? m[1].replace(/^www\./,'').replace(/^t\.me\/s\//,'TG: ').replace(/^t\.me\//,'TG: ') : 'Нове джерело';
  }
  try {
    await gfSaveSource({
      source_name: name, source_url: url.trim(),
      source_type:  isTg ? 'telegram' : (isRss||isNews) ? 'rss' : 'page',
      parser_mode:  isTg ? 'telegram' : isNews ? 'google_news_rss' : isRss ? 'rss' : 'page_links',
      source_status: 'active', source_priority: 'high',
      item_limit: '20', first_scan_mode: 'true', fetch_details: 'true', scan_window_days: '30',
      source_keywords: 'грант,гранти,грантова програма,конкурс,можливість,фінансування,підтримка,мікрогрант,grant,grants,funding,call,opportunity,application',
      link_include: 'грант,гранти,конкурс,можливість,фінансування,підтримка,мікрогрант,grant,grants,funding,call,opportunity,application',
      link_exclude: 'вакансія,job,jobs,career,about,contact,login,privacy,cookie,sitemap',
      found_count: 0
    });
    gfToast('Додано: ' + name, 'var(--green)');
    await gfRefresh(); gfGo('sources');
  } catch(e) { alert('Помилка: ' + e.message); }
}

async function gfAddFromCatalog(catalogId) {
  var c = GF_CATALOG.find(function(x) { return x.id === catalogId; });
  if (!c) return;
  try {
    await gfSaveSource(gfDefaultSourcePayload(c));
    gfToast('Додано: ' + c.name, 'var(--green)');
    await gfRefresh();
  } catch(e) { alert('Помилка: ' + e.message); }
}

async function gfBulkAddAll() {
  if (!confirm('Додати ВСІ ' + GF_CATALOG.length + ' джерел? Вже додані будуть пропущені.')) return;
  var existing     = (GF.data.sources||[]).map(function(s){ return (s.source_profile||'').toLowerCase(); });
  var existingUrls = (GF.data.sources||[]).map(function(s){ return (s.source_url||'').toLowerCase().replace(/\/+$/,''); });
  var added = 0, skipped = 0;
  try {
    for (var i = 0; i < GF_CATALOG.length; i++) {
      var c = GF_CATALOG[i];
      if (existing.indexOf(c.id.toLowerCase()) >= 0 || existingUrls.indexOf(c.url.toLowerCase().replace(/\/+$/,'')) >= 0) {
        skipped++; continue;
      }
      await gfSaveSource(gfDefaultSourcePayload(c));
      added++;
    }
    gfToast('Додано: ' + added + ', пропущено: ' + skipped, 'var(--green)');
    await gfRefresh(); GF.sourceView = 'active'; gfGo('sources');
  } catch(e) { alert('Помилка: ' + e.message); }
}

async function gfTogglePause(id) {
  var src = (GF.data.sources||[]).find(function(s){ return (s._id||s.source_id) === id; });
  if (!src) return;
  var newSt = src.source_status === 'active' ? 'paused' : 'active';
  try {
    await gfUpd(GFC.sources, id, { source_status: newSt });
    src.source_status = newSt;
    gfToast(src.source_name + ': ' + (newSt === 'active' ? 'Увімкнено' : 'Призупинено'));
    gfRender();
  } catch(e) { alert(e.message); }
}

async function gfArchiveSrc(id) {
  var reason = prompt('Причина архівації:', '');
  if (!reason) return;
  try {
    await gfArchiveSource(id, reason);
    gfToast('Архівовано', 'var(--red)');
    await gfRefresh();
  } catch(e) { alert(e.message); }
}

/* ── Статус-бейдж останнього сканування ── */
function gfSrcLogBadge(s) {
  var ll  = s.last_scan_log || {};
  var st  = ll.status || '';
  var ec  = s.last_error_code || ll.error_code || '';
  var el  = s.last_error_label || ll.error_label || '';
  if (!st && !ec) return '';

  if (ec) {
    var ecIcon = ec === 'TIMEOUT' ? '⏱️' : ec === 'ENOTFOUND' ? '🔍' : ec === 'HTTP_403' ? '🔐' : ec === 'HTTP_404' ? '❓' : ec === 'HTTP_5XX' ? '💥' : ec === 'ECONNRESET' ? '🔌' : '⚠️';
    return '<span style="color:var(--red)" title="' + gfE(el || ec) + '">' + ecIcon + ' ' + gfE(el || ec) + '</span>';
  }

  var color = st==='ok_new'    ? 'var(--green)'
            : st==='ok_dupes'  ? 'var(--accent)'
            : st==='filtered'  ? 'var(--yellow)'
            : st==='error'     ? 'var(--red)'
            : 'var(--muted)';
  var icon = st==='ok_new'   ? '✅ +' + (ll.created||0)
           : st==='ok_dupes' ? '♻️ дублі'
           : st==='filtered' ? '⚠️ 0'
           : st==='error'    ? '❌'
           : st==='empty'    ? '📭' : '—';
  return '<span style="color:' + color + '" title="' + gfE(ll.error||st) + '">' + icon + '</span>';
}

/* ── Discover: допоміжні функції ── */
function gfDiscoverOpen(url) { window.open(url, '_blank'); }

function gfDiscoverDismiss(host) {
  var d = JSON.parse(localStorage.getItem('gf_discover_dismissed')||'[]');
  if (d.indexOf(host) < 0) d.push(host);
  localStorage.setItem('gf_discover_dismissed', JSON.stringify(d));
  gfRender();
}

async function gfDiscoverAdd(host, url, suggestName) {
  var isTg = host.startsWith('telegram:');
  var name = suggestName || (isTg ? 'TG: ' + host.replace('telegram:','') : host);
  try {
    await gfSaveSource({
      source_name: name, source_url: url,
      source_type: isTg ? 'telegram' : 'page',
      parser_mode: isTg ? 'telegram' : 'page_links',
      source_status: 'active', source_priority: 'medium',
      item_limit: '10', scan_window_days: '7', scan_interval_min: '30',
      fetch_details: 'true', found_count: 0
    });
    await gfRefresh();
    var newSrc = (GF.data.sources||[]).find(function(s){
      return (s.source_url||'').toLowerCase().replace(/\/+$/,'') === url.toLowerCase().replace(/\/+$/,'');
    });
    if (newSrc) setTimeout(function(){ gfOpenSourceForm(newSrc._id||newSrc.source_id); }, 300);
    gfToast('Додано — відредагуй налаштування', 'var(--green)');
  } catch(e) { alert('Помилка: ' + e.message); }
}

/* ── Делегування для discover-кнопок ── */
function gfWireSources() {
  var content = gfId('gfContent');
  if (!content) return;
  // Переконуємося що не додаємо дублі
  if (content._gfSourcesWired) return;
  content._gfSourcesWired = true;

  content.addEventListener('click', function(e) {
    var btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.discOpen)       { window.open(btn.dataset.discOpen, '_blank'); return; }
    if (btn.dataset.discHost)       { gfDiscoverAdd(btn.dataset.discHost, btn.dataset.discUrl, btn.dataset.discName); return; }
    if (btn.dataset.discDismiss)    { gfDiscoverDismiss(btn.dataset.discDismiss); return; }
    if (btn.dataset.discRestoreOne) {
      var d = JSON.parse(localStorage.getItem('gf_discover_dismissed')||'[]');
      var idx = d.indexOf(btn.dataset.discRestoreOne);
      if (idx >= 0) { d.splice(idx, 1); localStorage.setItem('gf_discover_dismissed', JSON.stringify(d)); gfRender(); }
      return;
    }
    if (btn.hasAttribute('data-disc-restore')) { localStorage.removeItem('gf_discover_dismissed'); gfRender(); return; }
  });
}

/* ═══════════════════════════════════════════════════════════
   ОЧИСТКА ЛОГІВ СКАНУВАННЯ
   Видаляє всі збережені логи і скидає last_scan_log на джерелах.
   Корисно після деплою — в звіті будуть тільки свіжі результати.
   ═══════════════════════════════════════════════════════════ */
async function gfClearAllScanLogs() {
  if (!confirm(
    '🗑 Очистити всі логи сканування?\n\n' +
    'Це видалить усю історію сканувань і скине статус у джерел.\n' +
    'Після очистки в звіті будуть тільки нові результати після наступного сканування.\n\n' +
    'Натисніть OK щоб підтвердити.'
  )) return;

  // Показуємо індикатор
  gfToast('⏳ Очищаємо логи…', '#64748b');

  try {
    var resp = await fetch(GFC.fnBase + 'clearScanLogs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ all: true })
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    var result = await resp.json();
    if (!result.ok) throw new Error(result.error || 'Невідома помилка');

    gfToast(
      '✅ Очищено: ' + (result.deleted_logs || 0) + ' логів, ' +
      'скинуто ' + (result.reset_sources || 0) + ' джерел',
      'var(--green)'
    );

    // Оновлюємо дані й перемальовуємо
    await gfRefresh();
    gfRender();
  } catch(e) {
    // Якщо Cloud Function ще не задеплоєна — пробуємо очистити локально через Firestore напряму
    try {
      var db = firebase.firestore();
      // Скидаємо last_scan_log на всіх джерелах (доступно з клієнта)
      var snap = await db.collection(GFC.collections ? GFC.collections.sources : 'gf_sources').get();
      var batch = db.batch();
      snap.docs.forEach(function(d) {
        batch.update(d.ref, {
          last_scan_log: {},
          last_error: '',
          last_error_code: '',
          last_error_label: ''
        });
      });
      await batch.commit();
      gfToast('✅ Статуси скинуто (' + snap.size + ' джерел). Логи видаляться при наступній перевірці.', 'var(--green)');
      await gfRefresh();
      gfRender();
    } catch(e2) {
      alert('Помилка очистки: ' + e.message + '\n\nФallback: ' + e2.message);
    }
  }
}
